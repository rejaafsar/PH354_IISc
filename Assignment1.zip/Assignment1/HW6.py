from math import sqrt,pi

G,M=6.67*(10**(-11)),1.989*(10**30)



l1=float(input("Enter l1 perihilion dist. in m \n"))
v1=float(input("Enter velocit v1 at l1 in m/s\n"))

A=G*M/(l1*v1)
B=(G*M/l1)-(v1**2)/2

#calculation various quantites
v2=A-sqrt(A**2-2*B) 
l2=l1*v1/v2 
#eccentricity
e=(l2-l1)/(l2+l1) 
a=(l1+l2)/2 
b=a*sqrt(1-e**2) 
T=(2*pi*a*b)/(v1*l1) 


print ("v2=",v2," m per sec")
print ("l2 =",l2," m ")
print ("ecentricity e= ",e)
print ("time period T= ",T/(365*24*3600) ," yrs") 
