from math import pow
#value of the coefficients
a1,a2,a3,a4,a5=15.67,17.23,0.75,93.2,12.0
#calculation of BE and returning BE/A

def BE_per_A(Z,A):
    B=a1*A-a2*pow(A,(2.0/3.0))-a3*(Z*Z)/(pow(A,(1.0/3.0)))-a4*((A-2*Z)**2)/A
    if A%2==1:
        B=B
    elif Z%2==0:
        B=B+a5/pow(A,(1.0/5.0))
    else:
        B=B-a5/pow(A,(1.0/5.0))
    return B/A

maxBE_A_list=[] #list stores maxBE_A
for Z in range(1,101):
	BE_A=[]  # a list containing all BE/A for A going from Z to 3Z
	for A in range(Z,3*Z+1):
		BE_A.append(BE_per_A(Z,A))
	maxBE_A= max(BE_A) # sorting the max  BE/A 
	A=BE_A.index(maxBE_A) #index of the max BE/A
	maxBE_A_list.append(maxBE_A) 
	print ("for Z=",Z, "max  BE/A = ",maxBE_A, "MeV and most stable A =",A+Z,"\n")



print("\n max BE/A =",max(maxBE_A_list),"at Z=",maxBE_A_list.index(max(maxBE_A_list)))






	
