from matplotlib import pyplot as plt

r=1.0
rdata=[]
xdata=[0.5]
x=0.5
for i in range(1000):
    xprime=r*x*(1-x)
    xdata.append(xprime)
    rdata.append(r)
    x=xprime

plt.plot(rdata,xdata[:1000],"k.")
plt.xlabel("x")
plt.ylabel("xprime")
plt.show()


