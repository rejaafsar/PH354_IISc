from math import pow
#value of the coefficients

a1,a2,a3,a4,a5=15.67,17.23,0.75,93.2,12.0
def BE(Z,A):
    B=a1*A-a2*pow(A,(2.0/3.0))-a3*(Z*Z)/(pow(A,(1.0/3.0)))-a4*((A-2*Z)**2)/A
    if A%2==1:
        B=B
    elif Z%2==0:
        B=B+a5/pow(A,(1.0/5.0))
    else:
        B=B-a5/pow(A,(1.0/5.0))
    return B


#part_a
Z=int(input("Enter Z value\n"))
A=int(input("Enter A value\n"))
print ("Binding energy B is = ", BE(Z,A) ," MeV\n")
#Binding energy for Z=28 A=58 
print("Binding energy  for Z=28 A=58 is = ", BE(28,58), " MeV\n")

#part_b
BE_per_A=BE(Z,A)/A
print ("BE per A is B/A =",BE_per_A,"MeV\n")
