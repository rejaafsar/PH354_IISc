from numpy import empty
from matplotlib import pylab as plb



d=4
points=1000
dx=d/points
zi=empty([points,points],float)
for a in range(points):
    y=-2.0+a*dx # y coordinate
    for b in range(points):
        x=-2.0+b*dx #x coordinate
        z=0.0+0.0j
        for N in range(100):
            zprime=z**2+complex(x,y)
            if(abs(zprime)>2):
                zi[a,b]=0.0 # 0 if outside
                break
            else:
                z=zprime
                zi[a,b]=1.0 # 1 if inside

plb.imshow(zi,origin="lower")
plb.gray()
plb.show()

