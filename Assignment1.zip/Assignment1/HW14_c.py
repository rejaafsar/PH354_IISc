from math import pi,sin,cos,exp
import numpy as np
from matplotlib import pyplot as plt

xdata=[]
ydata=[]
for theta in np.arange(0,24*pi,0.1):
    r=exp(cos(theta))-2*cos(4*theta)+(sin(theta/12))**5
    x=r*cos(theta)
    y=r*sin(theta)
    xdata.append(x)
    ydata.append(y)

plt.plot(xdata,ydata)
plt.xlabel("x axis")
plt.ylabel("y axis")
plt.title("  Fey's function")
plt.show()
