from matplotlib import pyplot as plt
import numpy as np

data=np.loadtxt("sunspots.txt",float)
time=data[:,0]
sunspot=data[:,1]
avg=[]# this list contains the running average of the sunspot datapoints

#calculating avg
x=0
for i in range(5,len(time)-5):
	for j in range(i-5,i+4):
		x=x+sunspot[j]
	
	avg.append(x/10)
	x=0
	j=0
#plotting
plt.plot(time,sunspot,"b",label="original data")
plt.plot(time[5:len(time)-5],avg,"r",label="running average data")
plt.xlim(0,1001)
plt.xlabel("time ")
plt.ylabel(" sunspots")
plt.legend()
plt.show()
