from matplotlib import pyplot as plt
import numpy as np

r=np.arange(1,4,0.01)
x=0.5*np.ones(len(r))
for i in range(1000):
    x=r*x*(1-x)

plt.plot(r,x,"k.")
plt.show()
