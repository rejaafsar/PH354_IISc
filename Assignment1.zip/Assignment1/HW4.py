from math import  sqrt

x=float(input("enter the distance in light years\n"))
v=float(input("enter v/c  i.e velocity in terms of light speed\n"))

#part_a 
#in rest frame
t_rest=x/v
print("time required to reach x lyr away is=",t_rest,"\n")

#part_b 
#using time dialation formula
t_passenger=sqrt(1-v**2)*t_rest
print ("the time in spaceship frame is =",t_passenger ," years\n")

#############Ans of the question
x=10
v=0.99
print ("\nfor v=0.99c and t=10 lyrs the time in spaceship frame ",t_passenger ," years")

