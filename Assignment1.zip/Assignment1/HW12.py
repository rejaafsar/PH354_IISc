 #part_a function to define catalan number

def Cn(n):
    if n==0:
        return 1
    elif n>0:
        res= (4*n-2)*Cn(n-1)/(n+1)
    return res
print (Cn(10))

#part_b fn for greatest common devisor

def g(m,n): 
    if n==0:
        return m
    elif n>0:
        return g(n,m%n)

print (g(108,192))
