from math import pi,sin,cos
import numpy as np
from matplotlib import pyplot as plt

xdata=[]
ydata=[]
for theta in np.arange(0,2*pi,0.1):
    x=2*cos(theta)+cos(2*theta)
    y=2*sin(theta)-sin(2*theta)
    xdata.append(x)
    ydata.append(y)

plt.plot(xdata,ydata)
plt.xlabel("x axis")
plt.ylabel("y axis")
plt.title(" Deltoid curve ")
plt.show()
