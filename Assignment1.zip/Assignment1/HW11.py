from math import sqrt

prime_list=[2] 


for N in range(3,10000): 
	flag=1
	for j in range(len(prime_list)):
		if prime_list[j]<=int(sqrt(N)) and N%prime_list[j]==0:
			flag=0				
			break
	if flag == 1:
		prime_list.append(N)        
		print (N)


		 




