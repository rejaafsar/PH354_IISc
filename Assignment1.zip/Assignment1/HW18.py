
from matplotlib import pyplot as plt
import numpy as np

data=np.loadtxt("millikan.txt",float)
x=data[:,0]
y=data[:,1]
Ex=sum(x)/len(x) 
Ey=sum(y)/len(y) 
Exx=sum(x*x)/len(x) 
Exy=sum(x*y)/len(x) 
m=(Exy-Ex*Ey)/(Exx-Ex**2) 
c=(Exx*Ey-Ex*Exy)/(Exx-Ex**2) 
print ("slope= ",m," intercept ",c)
electron_charge=1.602*10**(-19)
h=electron_charge*m
print ("Planck's constant = ",h)

ydata=m*x+c # array that contains the y values corresponding to each x lying on y=mx+c st line
plt.plot(x,y,"ro",label="exp data")
plt.plot(x,ydata,"k-",label="fit data")
plt.xlabel("frequency in Hz")
plt.ylabel("Voltage in V")
plt.title("Photoelectric effect")
plt.legend()
plt.show()
