#import math
from math import pi, pow
#The standard paprmeters
G=6.67*(10**(-11)) #gravitational const.
M=5.97*(10**24)  # Mass of earth
R=6371*(10**3) #Radius of earth



#Part_a
 
t= float(input("Enter desired value of Time period T in hour\n"))
# altitude in meters  (G*M*T^2/4pi*pi)^(1/3)-R

def h(t):
	T=t*3600 #time in sec
	return (pow((G*M*T*T/(4*(pi)**2)),1/3)-R)

print(" altitude for time period",t,"hour is",h(t),"m\n\n")
#part_b 
#attach pdf file
print(" altitude for time period 24 hr =",h(24),"m\n\n")
print(" altitude for time period 90 min =",h(1.5),"m\n\n")
print(" altitude for time period 45 min =", h(0.75),"m\n\n")


#part_c
print("altitude difference for T= 24 hr & T=23.93 hr is", h(24)-h(23.93),"m\n")
