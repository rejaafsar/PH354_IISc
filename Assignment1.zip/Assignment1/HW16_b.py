from matplotlib import pyplot as plt
import numpy as np


rvalues=np.arange(1,4,0.01)
rdata = [] 
xdata = []

for r in rvalues:
    x = 0.5
    for i in range(1000):
        xprime=r*x*(1-x)
        xdata.append(xprime)
        rdata.append(r)
        x=xprime



plt.plot(rdata, xdata, "k.") # plotting r in horizontal axis and x in vertical axis
plt.xlabel("r")
plt.ylabel("x")
plt.show()


