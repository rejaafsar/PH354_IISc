# function to calculate n!
def factorial (n):
    if n==0:
        return 1
    else:
        x=1
        for i in range(1, n + 1):
            x=x*i
        return x


#part_a  binomial coefficient 
def binomial(n,m):
    bi=factorial(n)/(factorial(m)*factorial(n-m))
    bin=int(bi)
    return bin


#part_b  pascal triangle
n=int(input("Enter required no of lines of pascal triangle \n"))
for i in range(1,n+1):
	for j in range(i+1):
		print (binomial(i,j),end='')
	print("\n")
        

#part_c   tossed 100 times 
n=100
P=binomial(n,60)/(2**n)
print ("probability of getting 60 heads is ",P)

#to print probability of getting 60 or more heads
total_prob=0
for h in range(60,101):
    total_prob+=binomial(100,h)*(0.5)**100
print ("probability of getting 60 or more heads: ",total_prob)
