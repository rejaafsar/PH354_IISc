n,Cn=0,1
print (Cn)
while Cn<=10**9:
    Cn=Cn*(4*n+2)/(n+2)

    print (Cn)
    n += 1
