from math import atan,sqrt,pi

 # function definition to convert x,y into r, thetha

def polar(x,y): 
    r=sqrt(x**2+y**2)

    if x==0:
        theta=pi/2
    elif x>0 and y>=0:
        theta=(atan(y/x))
    elif x<0 and y>0:
        theta=pi-atan(y/-x)
    elif x<0 and y<0:
        theta = atan(y/x)-pi
    else:
        theta =- atan(-y/x)

    return r, theta * (180 / pi)

x=float(input("Enter x cordinate\n"))
y=float(input("Enter y cordinate\n"))
r,theta=polar(x,y)
print("\nr= ",r, " theta=", theta)
