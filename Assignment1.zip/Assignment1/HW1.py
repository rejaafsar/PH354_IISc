#Required time is given by T=Sqrt(2*h/g), h=hight, g=9.8m/s^2 with initial zero velocity 
import math
g=9.8
h=float(input("Enter hight of the tower in meter\n"))
t=math.sqrt(2*h/g)
print("the time the ball takes until it hits the ground from hight",h,"m is =", t ,"sec\n\n")

#the time for a ball dropped from a 100 m high tower
print("the time for a ball dropped from a 100 m high tower =",math.sqrt(2*100/g),"sec")

