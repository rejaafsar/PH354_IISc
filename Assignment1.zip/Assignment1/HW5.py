from math import  sqrt,pi

m=9.11*10**(-31) # MASS
h_cut=6.634/2*pi *10**(-34) #PLANCK const
E=float(input("enter kineteic energy E  in eV\n"))
V=float(input("enter potential energy V  in eV\n"))


k1=sqrt(2*m*E*1.602*10**(-19))/h_cut
k2=sqrt(2*m*(E-V)*1.602*10**(-19))/h_cut
T=4*k1*k2/(k1+k2)**2
R=1-T
print ("\nR=",R," and T= ",T)

###Ans of the question
E=10
V=9
print ("\nfor E=10eV and V=9eV R=",R," and T=",T)

