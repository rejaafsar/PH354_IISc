from matplotlib import pylab as plb
import numpy as np

data=np.loadtxt("stm.txt",float)
plb.imshow(data,origin="lower")
plb.hot()
plb.show()
