from math import pi,sin,cos
import numpy as np
from matplotlib import pyplot as plt

xdata=[]
ydata=[]
for theta in np.arange(0,10*pi,0.1):
    r=theta**2
    x=r*cos(theta)
    y=r*sin(theta)
    xdata.append(x)
    ydata.append(y)

plt.plot(xdata,ydata)
plt.xlabel("x axis")
plt.ylabel("y axis")
plt.title(" spiral curve ")
plt.show()
