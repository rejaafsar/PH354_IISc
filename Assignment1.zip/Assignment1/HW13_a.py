
from matplotlib import pyplot as plt 
import numpy as np


data=np.loadtxt("sunspots.txt",float)
time=data[:,0]
sunspot=data[:,1]

plt.plot(time,sunspot)
plt.title("sunspots function of time")
plt.xlabel("time ")
plt.ylabel(" sunspots")
plt.show()
