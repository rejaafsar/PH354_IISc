from math import cos,sin,pi
import numpy as np
from matplotlib import pylab as plb


def f(theta,m,x):
    return cos(m*theta-x*sin(theta))

#simpson's rule
#I=∫baf(x)dx=(∆x/3)[f(x0) + 4f(x1) + 2f(x2) + 4f(x3) +. . .2f(xn−1) + 4f(xn−1) +f(xn)]
#slices s

def simpson(a,b,s,m,x):
	h=(b-a)/s
	I=f(a,m,x)+f(b,m,x)
	for i in range(1,s):
		if i%2!=0:
			I=I+4*f(a+i*h,m,x)		
		else:
			I=I+2*f(a+i*h,m,x)
	return	I*h/3

def J(m,x):
	return simpson(0,pi,1000,m,x)/pi

J0=[]
J1=[]
J2=[]
xpts=[]
x=0
while x<20.1:
	J0.append(J(0,x))
	J1.append(J(1,x))
	J2.append(J(2,x))
	xpts.append(x)
	x=x+0.01

plb.plot(xpts,J0,"r",label="J0(x)")
plb.plot(xpts,J1,"y",label="J1(x)")
plb.plot(xpts,J2,"b",label="J2(x)")
plb.xlabel("x")
plb.ylabel("J(x)")
plb.legend()
plb.show()

	
#print("\n",J(0,1))
