from math import sqrt,sin

def simpson_1_3rd(a,b,interval,fx): # Simpson integration 
    h = (b - a) / interval
    I =  fx(a) + fx(b)
    for i in range(1, interval):
        x = a + i * h
        if i % 2 != 0: 
            I =I+4 * fx(x) 
        else:  
            I =I+ 2 * fx(x)
    return I*h/3


def f(x):
    return sin(sqrt(100*x))**2





epsilon=10**(-6)
i,j=2,4  
I1=simpson_1_3rd(0.,1.,i,f)
I2=simpson_1_3rd(0.,1.,j,f)
abs_err=abs(I2-I1)/15
print ("\nSlice=",i,"integration value=",I1)
print ("\nSlice=",j,"integration value=",I2,"absolute error=",abs_err)
while abs_err > epsilon:
    i=j
    j=2*j
    I1, I2 = simpson_1_3rd(0., 1., i, f), simpson_1_3rd(0., 1., j, f)
    abs_err=abs(I2-I1)/3
    print ("\nSlice=",j,"integration value=",I2,"absolute error=",abs_err)

