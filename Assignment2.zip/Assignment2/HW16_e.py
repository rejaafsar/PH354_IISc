import  numpy as np
from matplotlib import pylab as plb
from math import sin,pi,sqrt
from gaussxw import gaussxwab
from cmath import exp


def q(u):
    alpha=10**5*pi/2.0
    beta=alpha/2
    return (sin(alpha*u))**2*(sin(beta)*u)**2


Lambda=5.E-7
fL=1   #focal length
w=1.E-2 #grating width
N=20
upts,wu=gaussxwab(N,-w/2,w/2)

def f(x,u):
    v=q(u)
    return sqrt(v)*exp((2.0j*pi*x*u/(Lambda*fL)))

def Intensity(x):
    I=0
    for i in range(N):
        I +=wu[i]*f(x,upts[i])
    return (I.real)**2+(I.imag)**2

N_grid=100
length,width=0.1,0.05
dx,dy=length/N_grid,width/N_grid
Ipts=np.empty([N_grid,N_grid],float)
for i in range(N_grid):
    for j in range(N_grid):
        x=-0.05+j*dx
        Ipts[i,j]=Intensity(x)

plb.imshow(Ipts,aspect=0.5,extent=[-.05,0.05,0,0.05])
plb.gray()
plb.show()




