from gaussxw import gaussxwab
from math import sqrt, sin, cos, pi
import numpy as np
from matplotlib import pylab as plb

Lambda=1
N=50
z=3


def I_I0(x):
    u=x*sqrt(2./(Lambda*z))
    t,w=gaussxwab(N,0,u)
    I1=0
    I2 = 0
    for k in range(N):
        I1 +=w[k]*cos(0.5*pi*t[k]**2)
        I2 +=w[k]*sin(0.5*pi*t[k]**2)
    return ((2*I1+1)**2+(2*I2+1)**2)/8



xpts=np.arange(-5.,5.,0.01)
Ipts=[]
for x in xpts:
    Ipts.append(I_I0(x))

plb.plot(xpts,Ipts)
plb.xlabel("x ")
plb.ylabel(" I/Io")
plb.show()
