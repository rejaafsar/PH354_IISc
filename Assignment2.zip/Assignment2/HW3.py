from math import exp
import numpy as np
from matplotlib import pylab as plb

# the function
def f(t):  
    return exp(-t*t)


#simpson's rule
#I=∫baf(x)dx=(∆x/3)[f(x0) + 4f(x1) + 2f(x2) + 4f(x3) +. . .2f(xn−1) + 4f(xn−1) +f(xn)]
#slices s

def simpson(a,b,s,fx):
	h=(b-a)/s
	I=fx(a)+fx(b)
	for i in range(1,s):
		if i%2!=0:
			I=I+4*fx(a+i*h)		
		else:
			I=I+2*fx(a+i*h)
	return	I*h/3

x=np.arange(0,3.01,0.1) 
Ex=[]    
for j in x:
    val=simpson(0,j,100,f) #no of intervals s=500
    Ex.append(val)

plb.plot(x,Ex)
plb.xlabel("x")
plb.ylabel("E(x)")
plb.show()
















