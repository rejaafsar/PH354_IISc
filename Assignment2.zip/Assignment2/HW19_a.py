import numpy as np
from matplotlib import pylab as plb
from math import pi,sqrt,cos,sin

data=np.loadtxt("altitude.txt",float)
Nx,Ny=data.shape
h=30000.


dw_dx=np.empty([Nx,Ny],float)
for i in range(Nx):
    for j in range(Ny):
        if j!=Ny-1:
            dw_dx[i,j]=(data[i,j+1]-data[i,j])/h  # forward difference
        else:
            dw_dx[i,j]=(data[i,j]-data[i,j-1])/h  # backwd difference



dw_dy=np.empty([Nx,Ny],float)
for i in range(Nx):
    for j in range(Ny):
        if i!=Nx-1:
            dw_dy[i,j]=(data[i+1,j]-data[i,j])/h #  forward differerences
        else:
            dw_dy[i,j]=(data[i,j]-data[i-1,j])/h #  backward difference



angle=pi/4
Ipts=np.empty([Nx,Ny],float)
for i in range(Nx):
    for j in range(Ny):
        Ipts[i,j]=(cos(angle)*dw_dx[i,j]+sin(angle)*dw_dy[i,j])/sqrt(dw_dx[i,j]**2+dw_dy[i,j]**2+1)


plb.imshow(Ipts,vmax=5E-3,vmin=-5E-3)
plb.gray()
plb.show()
