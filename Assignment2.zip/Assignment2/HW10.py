from gaussxw import gaussxwab
from math import sqrt
import numpy as np
from matplotlib import pylab as plb


def f(a,x):
    return 1./sqrt(a**4-x**4)

m=1
N=20


def T(a):
    I = 0
    x,w=gaussxwab(N,0,a)
    for k in range(N):
        I += w[k] * f(a, x[k])
    return  I * sqrt(8 * m)

Tpts=[]
apts=np.arange(0.1,2.01,0.05) #exclude a=0 to avoid div.
for a in apts:
    Tpts.append(T(a))

plb.plot(apts,Tpts)
plb.xlabel("a")
plb.ylabel("T")
plb.show()


