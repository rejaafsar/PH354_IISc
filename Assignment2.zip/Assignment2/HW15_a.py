
from math import exp,pow
from matplotlib import pylab as plb
import numpy as np



def f(x,a):
	return pow(x,a-1)*exp(-x)


a_val=[2,3,4]
color=["r","g","b"]
label=["a=2","a=3","a=4"]
xpts=np.arange(0,5.001,0.01)
for i in range(3):
    a=a_val[i]
    fpts=[]
    for x in xpts:
        fpts.append(f(x,a))
    plb.plot(xpts,fpts,color=color[i],label=label[i])
plb.xlabel("x")
plb.ylabel("f(x,a)")
plb.legend()
plb.show()

      
