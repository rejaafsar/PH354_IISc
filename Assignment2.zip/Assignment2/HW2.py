import numpy as np

def f(x):
	return pow(x,4)-2*x+1

#simpson's rule
#I=∫baf(x)dx=(∆x/3)[f(x0) + 4f(x1) + 2f(x2) + 4f(x3) +. . .2f(xn−1) + 4f(xn−1) +f(xn)]
#slices s
s=1000
a=0
b=2
h=(b-a)/s
I=f(a)+f(b)
for i in range(1,s):
	if i%2!=0:
		I=I+4*f(a+i*h)
		#print("\n",i)
	else:
		I=I+2*f(a+i*h)
I=I*h/3
print("slice=",s," simpson value= ",I)
err=(I-4.4)*100/I   # error value in percentage
print ("error =",err,"%")
	
