from math import exp,sqrt,factorial,pi
from gaussxw import gaussxwab

def H(n,x):
    if n==0:
        return 1
    elif n==1:
        return 2*x
    else:
        return 2*x*H(n-1,x)-2*(n-1)*H(n-2,x)
def psi(n,x):
    N_norm = 1.0 / sqrt(2 ** n * factorial(n) * sqrt(pi))
    return N_norm*exp(-x*x/2)*H(n,x)

def g(z,n):
    return z**2*(psi(n,z/(1.-z)))**2./(1.-z)**4

N=100
z,w=gaussxwab(N,0,1)

def x_square(n):
    I = 0
    for i in range(N):
        I += w[i] * g(z[i], n)
    return 2*I
print ("uncertainty in position x in n=5")
print (sqrt(x_square(5)))
