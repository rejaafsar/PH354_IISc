import numpy as np

def f(x):
	return pow(x,4)-2*x+1


s=1000
b,a=2.,0. 
h=(b-a)/s # step size
I= 0.5 * h * (f(a) + f(b))
for i in range(1,s):
    x=a+i*h
    I += h * f(x)

print("slice=",s," Trapezoidal value= ",I)
err=(I-4.4)*100/I   # error value in percentage
print ("error =",err,"%")
