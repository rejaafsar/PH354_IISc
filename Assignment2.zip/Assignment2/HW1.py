import numpy as np
from matplotlib import pyplot as plt

datalist=np.loadtxt("velocities.txt",float)
t=datalist[:,0]  # time data
v=datalist[:,1] # velocity data
l=len(t) # length of the data set which is 101
x=np.empty([l],float) 
x[0]=0.0
sum=0
for i in range(1,len(t)):
    sum +=0.5*(v[i-1]+v[i])
    x[i]=sum     #trapezoidal integration 

plt.plot(t,v,"b",label="velocity")
plt.plot(t,x,"r",label="distance")
plt.xlabel("time ")
plt.ylabel("vel, distance")
plt.legend()
plt.show()
