import numpy as np
from math import sqrt
from matplotlib import pylab as plb

N_grid=100
length,width=1.,1.
x1,y1=-0.05,0.0
x2,y2=0.05,0.0
dx,dy=length/N_grid,width/N_grid
V=np.empty([N_grid,N_grid],float)
for i in range(N_grid):
    for j in range(N_grid):
        x=-0.5+j*dx
        y=-0.5+i*dy
        V[i,j]=(1./sqrt((x-x2)**2+(y-y2)**2)-1./sqrt((x-x1)**2+(y-y1)**2))

plb.imshow(V,origin="lower",vmax=1.,vmin=-1.)
plb.hsv()
plb.show()
