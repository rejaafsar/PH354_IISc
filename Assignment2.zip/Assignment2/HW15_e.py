from math import exp, log
from gaussxw import gaussxwab
 
def g(z,a):
    c=a-1
    return exp(c*log(c*z/(1.0-z))-c*z/(1.0-z))*c/(1.-z)**2
N=100
z,w= gaussxwab(N,0,1)

def gamma(a):
    I=0
    for i in range(N):
        I +=w[i]*g(z[i],a)
    return I
print ("gamma(3/2)=", gamma(1.5))
print ( "gamma(3)=",gamma(3),"\ngamma(6)=",gamma(6),"\ngamma(10)=",gamma(10))
