from math import sqrt,sin,pow


#trapezoidal inegration
def Trape(a,b,interval,fx):   
    h = (b - a) / interval
    I = 0.5 * h * (fx(a) + fx(b))
    for i in range(1, interval):
        x = a + i * h
        I += h * fx(x)
    return I


def f(x):
    return sin(sqrt(100*x))**2


e=pow(10,-6)
i,j=1,2
I1=Trape(0.,1.,i,f)
I2=Trape(0.,1.,j,f)
abs_err=abs(I2-I1)/3
print ("\nSlice=",i,"integration value=",I1)
print ("\nSlice=",j,"integration value=",I2,"absolute error=",abs_err)
while abs_err > e:
    i=j
    j=2*j
    I1, I2 = Trape(0., 1., i, f), Trape(0., 1., j, f)
    abs_err=abs(I2-I1)/3
    print ("\nSlice=",j,"integration value=",I2,"absolute error=",abs_err)

#**********************************Romberg Integration***************************************t
