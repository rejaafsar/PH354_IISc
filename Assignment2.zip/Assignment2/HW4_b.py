from math import cos,sin,pi,sqrt,pow
import numpy as np
from matplotlib import pylab as plb


def f(theta,m,x):
    return cos(m*theta-x*sin(theta))

#simpson's rule
#I=∫baf(x)dx=(∆x/3)[f(x0) + 4f(x1) + 2f(x2) + 4f(x3) +. . .2f(xn−1) + 4f(xn−1) +f(xn)]
#slices s

def simpson(a,b,s,m,x):
	h=(b-a)/s
	I=f(a,m,x)+f(b,m,x)
	for i in range(1,s):
		if i%2!=0:
			I=I+4*f(a+i*h,m,x)		
		else:
			I=I+2*f(a+i*h,m,x)
	return	I*h/3

def J(m,x):
	return simpson(0,pi,1000,m,x)/pi

Lambda=.5 #micrometer
k=2*pi/Lambda
epsilon=0.5
x=-1
y=-1



Length,Width=1.,1. 
N_grid=100
origin_x=Length/2  
origin_y=Width/2   
dx,dy=Length/N_grid,Width/N_grid
epsilon=0.5  # when kr is less than this value, I will take Ipts as 0.25
Ipts=np.empty([N_grid,N_grid],float)

for i in range(N_grid):
    for j in range(N_grid):
        x=j*dx
        y=i*dy
        r=sqrt((x-origin_x)**2+(y-origin_y)**2)
        if k*r < epsilon:    # when kr is small, Ipts =0.25
            Ipts[i,j]=0.25
        else:
            Ipts[i,j]=(J(1,k*r)/k*r)**2

plb.imshow(Ipts,origin="lower",vmax=0.001)
plb.gray()
plb.show()



