from math import exp,sqrt,factorial,pi
import numpy as np
from matplotlib import pylab as plb

def H(n,x):
    if n==0:
        return 1
    elif n==1:
        return 2*x
    else:
        return 2*x*H(n-1,x)-2*(n-1)*H(n-2,x)



def psi(n,x):
    return exp(-x*x/2)*H(n,x)/sqrt(2**n*factorial(n)*sqrt(pi))

xpts=np.arange(-10,10.1,0.1)
psi30=[]

for x in xpts:
        psi30.append(psi(30,x))

plb.plot(xpts,psi30,"r",label="psi30")

plb.xlabel("x")
plb.ylabel("psi30")
plb.legend()
plb.show()


