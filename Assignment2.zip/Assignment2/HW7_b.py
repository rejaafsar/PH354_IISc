
from math import sqrt,sin

#trapezoidal inegration
def Trape(a,b,interval,fx):   
    h = (b - a) / interval
    I = 0.5 * h * (fx(a) + fx(b))
    for i in range(1, interval):
        x = a + i * h
        I += h * fx(x)
    return I



def f(x):
    return sin(sqrt(100*x))**2





def RI(i,m): # defining the function that gives RI(i,m)
    if i >= m & m==1:
        return Trape(0.,1.,1*2**(i-1),f)
    elif i >= m & m!=1:
        return RI(i,m-1)+(RI(i,m-1)-RI(i-1,m-1))/(4**(m-1)-1)

e=10**(-6)
i,m=1,1
abs_err=abs(RI(i+1,m)-RI(i,m))/3
#print (RI(i,m))
while abs_err > e:
    i +=1
    for m in range(1,i+1):
        print (RI(i,m),sep=" ")
    print ()
    abs_err=abs(RI(i,i-1)-RI(i-1,i-1))/(4**(i-1)-1)








