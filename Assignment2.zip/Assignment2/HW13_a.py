from math import exp,sqrt,factorial,pi
import numpy as np
from matplotlib import pylab as plb

def H(n,x):
    if n==0:
        return 1
    elif n==1:
        return 2*x
    else:
        return 2*x*H(n-1,x)-2*(n-1)*H(n-2,x)



def psi(n,x):
    return exp(-x*x/2)*H(n,x)/sqrt(2**n*factorial(n)*sqrt(pi))


# Drawing the plot for n=0,1,2,3


xpts=np.arange(-4,4.001,0.05)
psi0 = []
psi1=[]
psi2=[]
psi3=[]


for x in xpts:
        psi0.append(psi(0,x))
        psi1.append(psi(1,x))
        psi2.append(psi(2,x))
        psi3.append(psi(3,x))


plb.plot(xpts,psi0,"r",label="psi0")
plb.plot(xpts,psi1,"g",label="psi1")
plb.plot(xpts,psi2,"b",label="psi2")
plb.plot(xpts,psi3,"y",label="psi3")

plb.xlabel("x")
plb.ylabel("psi")
plb.legend()
plb.show()












