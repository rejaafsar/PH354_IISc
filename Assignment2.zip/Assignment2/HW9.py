from gaussxw import gaussxwab
from math import exp,pow
from matplotlib import pylab as plb
import numpy as np

V=10**-3 # in m^3
rho=6.022*10**28
KB=1.38*10**-23
thetaD=428
constant=9*V*rho*KB/thetaD**3

N=50



def f(x):
    return exp(x)*pow(x,4)/pow((exp(x)-1),2)

def Cv(T):
    a=0
    b=thetaD/T
    x,w=gaussxwab(N,a,b)
    I=0
    for k in range(N):
        I +=w[k]*f(x[k])

    return constant*I*T**3

Cv_list=[]
Temp_list= np.arange(5,500.2,0.5)
for temp in Temp_list:
    Cv_list.append(Cv(temp))

plb.plot(Temp_list,Cv_list,"r")
plb.xlabel("T")
plb.ylabel("Cv")
plb.show()
