
def simpson_1_3rd(a,b,interval,fx): # Simpson integration 
    h = (b - a) / interval
    I =  fx(a) + fx(b)
    for i in range(1, interval):
        x = a + i * h
        if i % 2 != 0: 
            I =I+4 * fx(x) 
        else:  
            I =I+ 2 * fx(x)
    return I*h/3

def f(x):
    return x ** 4 - 2 * x + 1

I1=simpson_1_3rd(0.,2.,10,f)
I2=simpson_1_3rd(0.,2.,20,f)
aprox_err=(I2-I1)/15
real_err=4.4-I2
print ("\napprox error=",aprox_err,"\treal error=",real_err)
