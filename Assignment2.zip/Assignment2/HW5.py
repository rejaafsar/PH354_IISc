
#trapezoidal inegration
def Trape(a,b,interval,fx):   
    h = (b - a) / interval
    I = 0.5 * h * (fx(a) + fx(b))
    for i in range(1, interval):
        x = a + i * h
        I += h * fx(x)
    return I

def f(x):
    return x**4-2*x+1

I1=Trape(0.,2.,10,f)
I2=Trape(0.,2.,20,f)
aprox_err=(I2-I1)/3
real_err=4.4-I2
print ("\napprox error=",aprox_err,"\treal error=",real_err)

