from gaussxw import gaussxwab
from math import exp,pi,pow

#changing variable z=x/1+x we got the following function

def g(z):
    return (pow(z,3)/(pow((1-z),5)*(exp(z/(1-z))-1)))

KB=1.38064*10**-23
hcut=1.054*10**-34
c=3*10**8
const=KB**4/(hcut*(2*pi*c*hcut)**2)

N=30
x,w=gaussxwab(N,0,1)
I=0

for i in range(N):
    I +=w[i]*g(x[i])
print ("integration value ",I)
print ("Sigma = ",const*I,"sigma from online=",5.670*10**(-8))

