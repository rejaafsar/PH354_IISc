from math import factorial,pi
from cmath import exp

def f(z):
    return exp(2*z)

def D(fx,m):
    N=10000
    I=0
    for k in range(N):
        z= exp(2j*pi*k/N)
        I +=fx(z)*exp(-2j*pi*k*m/N)
    return factorial(m)*I/N
for m in range(21):
    print (m,"th\tderivative=",D(f,m).real)
