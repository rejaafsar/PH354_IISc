from gaussxw import gaussxwab
from matplotlib import pylab as plb
import numpy as np

def f(x,y,z):
    return 1./(x**2+y**2+z**2)**1.5

G=6.674*10**-11
L=10.
sigma=10*1000./L**2
N=100
x,w=gaussxwab(N,-5,5)
y,v=gaussxwab(N,-5,5)


def F(z):
    I = 0
    for i in range(N):
        for j in range(N):
            I += w[i] * v[j] * f(x[i], y[j], z)
    return 4*G*sigma*z*I


# Plotting
Fpts=[]
zpts=np.arange(0,10.001,0.01)
for z in zpts:
    Fpts.append(F(z))
plb.plot(zpts,Fpts)
plb.xlabel("z")
plb.ylabel("F(z)")
plb.title("Force vs z")
plb.show()
