#!/usr/bin/env python
# coding: utf-8

# In[1]:


#hw7
import numpy as np
import matplotlib.pyplot as plt

def fx(x):
    return x

def fvx(t, x):
    y[0] = k*(x[1]-x[0])+np.cos(w*t)
    y[N-1] = k*(x[N-2]-x[N-1])
    for i in range(1,N-1):
        y[i] = k*(x[i-1]+x[i+1]-2*x[i])
    return y

k = 6.0
w = 2.0
N = 5

t = np.linspace(0,20,10000)
h = t[1]-t[0]

r = np.zeros(shape=(len(t),N))
v = np.zeros(shape=(len(t),N))
y = np.zeros(N)

r[0] = np.zeros(N)

for i in range(0,len(t)-1):
    k0 = h*fx(v[i])
    l0 = h*fvx(t[i], r[i])

    k1 = h*fx(v[i]+0.5*l0)
    l1 = h*fvx(t[i]+0.5*h, r[i]+0.5*k0)

    k2 = h*fx(v[i]+0.5*l1)
    l2 = h*fvx(t[i]+0.5*h, r[i]+0.5*k1)

    k3 = h*fx(v[i]+l2)
    l3 = h*fvx(t[i]+h, r[i]+k2)

    r[i+1] = r[i]+(k0+2*k1+2*k2+k3)/6.0
    v[i+1] = v[i]+(l0+2*l1+2*l2+l3)/6.0

for i in range(0, len(r[0])):
    plt.plot(t, r[:,i], label='%d' %(i+1))

plt.xlabel("t")
plt.title("position of masses")
plt.legend(ncol=5)
plt.show()


# In[ ]:




