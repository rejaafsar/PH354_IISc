#!/usr/bin/env python
# coding: utf-8

# In[18]:


#hw_10

from pylab import plot,show,xlabel,ylabel,title,show

def fx(x,y):
    return x
def fvx(x,y):
    return -G*M*x/(x*x+y*y)**(3.0/2)
def fy(x,y):
    return y
def fvy(x,y):
    return -G*M*y/(x*x+y*y)**(3.0/2)

h = 3600.0
G = 6.6738*10**(-11)
M = 1.9891*10**30


xlist = []
vxlist = []
ylist = []
vylist = []

xlist.append(1.471*10**11)
vxlist.append(0.0)
ylist.append(0.0)
vylist.append(3.0287*10**4)



vxlist.append(vxlist[0]+0.5*h*fvx(xlist[0], ylist[0]))
xlist.append(xlist[0]+h*vxlist[1])

vylist.append(vylist[0]+0.5*h*fvy(xlist[0], ylist[0]))
ylist.append(ylist[0]+h*vylist[1])

i = 0
while (i<10000):
    k1 = h*fvx(xlist[i+1], ylist[i+1])
    vxlist.append(vxlist[-1] + 0.5*k1)
    vxlist.append(vxlist[-2] + k1)
    k2 = h*fvy(xlist[i+1], ylist[i+1])
    vylist.append(vylist[-1] + 0.5*k2)
    vylist.append(vylist[-2] + k2)
    xlist.append(xlist[-1]+h*vxlist[-1])
    ylist.append(ylist[-1]+h*vylist[-1])
    i = i+1

plot(xlist, ylist)
xlabel("x")
ylabel("y")
title("earth orbit")


show()


# In[ ]:




