#!/usr/bin/env python
# coding: utf-8

# In[3]:


#hw_1

import numpy as np
import matplotlib.pyplot as plt

def f(RC,x,t):
    if int(t+1)%2==0:
        Vin=1
        return (Vin-x)/RC
    else:
        Vin=-1
        return (Vin-x)/RC

a=0
b=10
N=1000 #steps
h=(b-a)/N


tpts=np.arange(a,b,h)
xpts=[]
x = 0.0

RC=.01

for t in tpts:
    xpts.append(x)
    k1 = h*f(RC,x,t)
    k2 = h*f(RC,x+0.5*k1,t+0.5*h)
    k3 = h*f(RC,x+0.5*k2,t+0.5*h)
    k4 = h*f(RC,x+k3,t+h)
    x += (k1+2*k2+2*k3+k4)/6

plt.plot(tpts,xpts)
plt.xlabel("t")
plt.ylabel("Vo")
plt.title("RC=0.01")
plt.show()


# In[ ]:




