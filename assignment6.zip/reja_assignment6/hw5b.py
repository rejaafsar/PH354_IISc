#!/usr/bin/env python
# coding: utf-8

# In[13]:


#hw_5b
from numpy import append,array,arange
from math import sqrt,pi
from pylab import plot, show, xlabel,ylabel,title,ylim



mlist=[1,2,3]
R=0.08
rho=1.22
C=0.47
K=(pi*R**2*rho*C)/(2) #constant
g=9.8


def f(r,K):
    x=r[0]
    vx=r[1]
    y=r[2]
    vy=r[3]
    fx=vx
    fvx=-K*vx*sqrt(vx**2+vy**2)
    fy=vy
    fvy=-g-K*vy*sqrt(vx**2+vy**2)
    
    return array([fx,fvx,fy,fvy],float)


for m in mlist:
    K=K/m

    ti=0.0
    tf=50.0
    N=1000
    h=(tf-ti)/N
    tpts=arange(ti,tf+0.0001,h)


    vx0=50*sqrt(3)
    vy0=50
    r=[0.0,vx0,0.0,vy0]
    rpts=[]



    for t in tpts:
        rpts.append(list(r))
        k1=h*f(r,K)
        k2=h*f(r+k1/2,K)
        k3=h*f(r+k2/2,K)
        k4=h*f(r+k3,K)
        r +=(k1+2*k2+2*k3+k4)/6.0


    xpts=array(rpts)[:,0]
    ypts=array(rpts)[:,2]
    plot(xpts,ypts,label= str(mlist[m-1]))
    ylim(0.0,200.0)
    ylabel('y')
    xlabel('x')
title('trajectory different masses')
show()


# In[ ]:




