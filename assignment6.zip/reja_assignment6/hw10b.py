#!/usr/bin/env python
# coding: utf-8

# In[20]:


#hw_10b
from math import sqrt
from pylab import plot,show,xlabel,ylabel,legend,show,title


def fx(x,y):
    return x
def fvx(x,y):
    return -G*M*x/(x*x+y*y)**(3.0/2)
def fy(x,y):
    return y
def fvy(x,y):
    return -G*M*y/(x*x+y*y)**(3.0/2)

h = 3600.0
G = 6.6738*10**(-11)
M = 1.9891*10**30
m = 5.9722*10**24

x = []
vx = []
y = []
vy = []
PE = []
KE = []
TE = []
t = []

x.append(1.471*10**11)
vx.append(0.0)
y.append(0.0)
vy.append(3.0287*10**4)




t.append(0)
PE.append(-G*M*m/sqrt(x[0]*x[0]+y[0]*y[0]))
KE.append(0.5*m*(vx[0]*vx[0]+vy[0]*vy[0]))
TE.append(PE[0]+KE[0])

vx.append(vx[0]+0.5*h*fvx(x[0], y[0]))
x.append(x[0]+h*vx[1])

vy.append(vy[0]+0.5*h*fvy(x[0], y[0]))
y.append(y[0]+h*vy[1])





i = 0
while (i<10000):
    k1 = h*fvx(x[i+1], y[i+1])
    vx.append(vx[-1] + 0.5*k1)
    a = vx[-1]
    vx.append(vx[-2] + k1)
    k2 = h*fvy(x[i+1], y[i+1])
    vy.append(vy[-1] + 0.5*k2)
    b = vy[-1]
    vy.append(vy[-2] + k2)
    

    t.append(h*(i+1))
    PE.append(-G*M*m/sqrt(x[i+1]*x[i+1]+y[i+1]*y[i+1]))
    KE.append(0.5*m*(a*a+b*b))
    TE.append(PE[i+1]+KE[i+1])

    x.append(x[-1]+h*vx[-1])
    y.append(y[-1]+h*vy[-1])
    i = i+1

plot(t, PE, c='y', label='Potential Energy')
plot(t, KE, c='g', label='Kinetic Energy')
plot(t, TE, c='c', label='Total Energy')
ylabel("Energy")
xlabel("time")
legend()
title("Energy vs time plot ")

show()
# part c


plt.plot(t,TE,label='energy')
plt.ylabel('energy')
plt.xlabel('t')
plt.legend()
plt.savefig('Downloads/que_10_part_C.jpg')

plt.show()


# In[ ]:




