#!/usr/bin/env python
# coding: utf-8

# In[14]:


#hw_5
from numpy import append,array,arange
from math import sqrt,pi
from pylab import plot, show, xlabel,ylabel,title,ylim



m=1.0
R=0.08
rho=1.22
C=0.47
K=(pi*R**2*rho*C)/(2*m) #constant
g=9.8



def f(r):
    x=r[0]
    vx=r[1]
    y=r[2]
    vy=r[3]
    fx=vx
    fvx=-K*vx*sqrt(vx**2+vy**2)
    fy=vy
    fvy=-g-K*vy*sqrt(vx**2+vy**2)
    
    return array([fx,fvx,fy,fvy],float)




ti=0.0
tf=50.0
N=1000
h=(tf-ti)/N
tpts=arange(ti,tf+0.0001,h)


vx0=50*sqrt(3)
vy0=50
r=[0.0,vx0,0.0,vy0]
rpts=[]



for t in tpts:
    rpts.append(list(r))
    k1=h*f(r)
    k2=h*f(r+k1/2)
    k3=h*f(r+k2/2)
    k4=h*f(r+k3)
    r +=(k1+2*k2+2*k3+k4)/6.0


xpts=array(rpts)[:,0]
ypts=array(rpts)[:,2]
plot(xpts,ypts)
ylim(0.0,100.0)
ylabel('y')
xlabel('x')
title('trajectory')
show()



# In[ ]:




