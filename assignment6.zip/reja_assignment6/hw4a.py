#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#hw_4a


import numpy as np
import matplotlib.pyplot as plt


a=0
b=50
N=10**7 #steps
h=(b-a)/N

tpts=np.arange(a,b,h)



w=1 #omega
xpts=[]
ypts=[]

x=1
y=0.0

def fx(x,y):
    return y
def fy(x,y):
    return -w*w*x

    
for t in tpts:
    xpts.append(x)
    ypts.append(y)
    
    k1x = h*fx(x,y)
    k2x = h*fx(x+0.5*k1x,y)
    k3x = h*fx(x+0.5*k2x,y)
    k4x = h*fx(x+k3x,y)
    
    k1y = h*fy(x,y)
    k2y = h*fy(x,y+0.5*k1y)
    k3y = h*fy(x,y+0.5*k2y)
    k4y = h*fy(x,y+k3y)
    
    x += (k1x+2*k2x+2*k3x+k4x)/6
    y += (k1y+2*k2y+2*k3y+k4y)/6
    
plt.plot(tpts,xpts,label="x(t)")
#plt.plot(tpts,ypts,label="y(t)")

plt.show()
    
    


# In[ ]:




