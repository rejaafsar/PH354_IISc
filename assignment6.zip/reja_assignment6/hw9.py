#!/usr/bin/env python
# coding: utf-8

# In[16]:


#hw_9
import numpy as np
from matplotlib import pyplot as plt


def fx(t,x,y):
    return y
def fy(t,x,y):
    return y*y-x-5.0

h = 0.001
t = np.arange(0,50,h)
x = []
y = []
x.append(1.0)
y.append(0.0)

y.append(y[0]+0.5*h*fy(t[0], x[0], y[0]))

for i in range(len(t)-1):
    x.append(x[i]+h*fx(t[i]+0.5*h, x[i], y[i+1]))
    y.append(y[i]+h*fy(t[i]+h, x[i+1], y[i+1]))


plt.plot(t, x)
plt.title("x vs t")
plt.show()


# In[ ]:




