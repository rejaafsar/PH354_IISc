#!/usr/bin/env python
# coding: utf-8

# In[15]:


#hw6

from numpy import append,array,arange
from math import sqrt,pi
from pylab import plot, show, xlabel,ylabel,title


G=1.0
L=2.0
M=10.0
K=G*M/L #const



def f(r):
    x=r[0]
    vx=r[1]
    y=r[2]
    vy=r[3]
    R=sqrt(x**2+y**2)
    fx=vx
    fvx=-K*x/(R**2*sqrt(R**2+L**2/4))
    fy=vy
    fvy=-K*y/(R**2*sqrt(R**2+L**2/4))
    
    return array([fx,fvx,fy,fvy],float)



ti=0.0
tf=50.0
N=10**4
h=(tf-ti)/N
tpts=arange(ti,tf+0.0001,h)



r=[1.0,0.0,0.0,1.0]
rpts=[]


for t in tpts:
    rpts.append(list(r))
    k1=h*f(r)
    k2=h*f(r+k1/2)
    k3=h*f(r+k2/2)
    k4=h*f(r+k3)
    r +=(k1+2*k2+2*k3+k4)/6.0
    


xlist=array(rpts)[:,0]
ylist=array(rpts)[:,2]
plot(xlist,ylist)

ylabel('y')
xlabel('x')
title('trajectory')
show()




# In[ ]:




