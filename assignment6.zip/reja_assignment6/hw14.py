#!/usr/bin/env python
# coding: utf-8

# In[21]:


#hw14

import numpy as np
import matplotlib.pyplot as plt

u0=1
v0=0

def fu(u,v):
    return 998*u+1998*v
def fv(u,v):
    return -999*u-1999*v
h=0.001
t=np.arange(0,10,h)
u=np.zeros(len(t))
v=np.zeros(len(t))
u[0]=u0
v[0]=v0
for i in range(1,len(t)):
    u[i]=u[i-1]+fu(u[i-1],v[i-1])*h
    v[i]=v[i-1]+fv(u[i-1],v[i-1])*h
plt.plot(t,u,label='u')
plt.plot(t,v,label='v')
plt.xlabel("t")
plt.legend()

plt.show()

# backword eular

u=np.zeros(len(t))
v=np.zeros(len(t))
u[0]=u0
v[0]=v0


for i in range(1,len(t)):
    u[i]=u[i-1]+fu(u[i],v[i])*h
    v[i]=v[i-1]+fv(u[i],v[i])*h
plt.plot(t,u,label='u')
plt.plot(t,v,label='v')
plt.xlabel("t")
plt.legend()
plt.show()


# In[ ]:




