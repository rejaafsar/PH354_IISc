#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#hw4_a_e
from numpy import loadtxt
from numpy.fft import rfft,irfft
from pylab import plot, show,title, xlabel,ylabel,legend
y=loadtxt("dow.txt")
plot(y)
title(" price vs time")
show()
#%% fft and plot
c=rfft(y)
N=len(c)

#print(len(y),N)

for i in range(int(0.1*N),N,1):
    c[i]=0
y_ift=irfft(c)
plot(y,color='red',label='data')
plot(y_ift,color='blue',label='ift')
legend()
xlabel("time")
ylabel('stock price')
show()

#%%  2 percent of fourier coeff to zero
c=rfft(y)
for i in range(int(0.02*N),N,1):
    c[i]=0
y_ift=irfft(c)
plot(y,color='red',label='data')
plot(y_ift,color='blue',label='ift')
legend()
xlabel("time")
ylabel('stock price')
show()

