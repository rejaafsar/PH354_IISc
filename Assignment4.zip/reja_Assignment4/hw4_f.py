#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#hw4_f
from numpy.fft import rfft,irfft
from pylab import plot,xlabel,ylabel,show,title,legend
from numpy import arange
N=1000
t_list=arange(0,1.00001,1./N)
y=[]
for t in t_list:
    if t<=0.5:
        y.append(-1)
    else:
        y.append(1)
plot(t_list,y)
show()
#%%  fft and ifft
c=rfft(y)
for i in range(10,len(c),1):
    c[i]=0
#print(c)    
y_ift=irfft(c)
plot(y,label='square wave')
plot(y_ift,label='ift')
legend()
#xlabel('steps')
ylabel('y')
title('data and ift plot')

