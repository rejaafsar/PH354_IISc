#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#hw7

from math import pi,sin
from numpy import zeros,empty
from numpy.fft import rfft
from pylab import plot, show,xlabel,ylabel,title
from pylab import imshow
# length are in  micro meter unit

alpha=pi/20
w=200.
W=10*w
wavelength=0.5
f=1.E6
N=20000.
# y values
y=zeros([int(N)],float)
for n in range(2000):
    y[n]=sin(alpha*w*(n/N-0.5))
c=rfft(y)
# Intensity
x=empty(400)
I=empty(400)
for k in range(400):
    x[k]=wavelength*f*(k-200)/(W*10**4) #  10^4 to convert in cm unit
    I[k]=W**2*abs(c[abs(k-200)])/N**2
#print(x[399])
#plotting
plot(x,I)
xlabel('x')
ylabel('Intensity')
title('diffraction pattern')
show()
# density plot
Intensity=empty([400,400],float)
for i in range(400):
    for j in range(400):
        Intensity[i,j]=I[j]
    
imshow(Intensity,extent=[-5,5,0,5],aspect=0.4)

