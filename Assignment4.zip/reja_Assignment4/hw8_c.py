#!/usr/bin/env python
# coding: utf-8

# In[2]:


#hw8_c
from numpy import loadtxt,shape,linspace,empty
from numpy.fft import rfft2,irfft2
from math import exp
from pylab import imshow

blurred_data=loadtxt("blur.txt",float)  # read the blurred data
row,col=shape(blurred_data)[0],shape(blurred_data)[1]
sigma=25
def fxy(x,y):
    return(exp(-(x**2+y**2)/(2*sigma**2)))
lim=25
x_unit=2*lim/col
y_unit=2*lim/row
point_spread_data=empty([row,col],float) # generate the point spread datapoints
for i in range(row):
    for j in range(col):
        x=x_unit*(col/2-(max(j,col/2)-min(j,col/2)))
        y=y_unit*(row/2-(max(i,row/2)-min(i,row/2)))
        point_spread_data[i,j]=fxy(x,y)

b=rfft2(blurred_data)  
f=rfft2(point_spread_data)


K,L=lim,lim
epsil=0.001
a=empty([row,int(col/2)+1],complex)
for k in range(row):
    for l in range(int(col/2)+1):
        if f[k,l]<epsil:
            a[k,l]= b[k,l]
        else:
            a[k,l]=b[k,l]/f[k,l]  # divide one by other
a=a/(K*L) 
true_image=irfft2(a) 
imshow(true_image) 


# In[ ]:




