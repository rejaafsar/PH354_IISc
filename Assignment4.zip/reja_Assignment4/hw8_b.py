#!/usr/bin/env python
# coding: utf-8

# In[2]:


from numpy import loadtxt,shape,linspace,empty
from math import exp
from pylab import imshow,gray
# spread data generation
data=loadtxt("blur.txt",float)
row,col=shape(data)[0],shape(data)[1]
#print(row,col)
sigma=25
def f(x,y):
    return(exp(-(x**2+y**2)/(2*sigma**2)))
lim=100
x_unit=2*lim/col
y_unit=2*lim/row
point_spread_data=empty([row,col],float)
for i in range(row):
    for j in range(col):
        x=x_unit*(col/2-(max(j,col/2)-min(j,col/2)))
        y=y_unit*(row/2-(max(i,row/2)-min(i,row/2)))
        point_spread_data[i,j]=f(x,y)

imshow(point_spread_data,origin='lower')
gray()


# In[ ]:




