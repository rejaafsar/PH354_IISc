#!/usr/bin/env python
# coding: utf-8

# In[1]:


#prob2
import numpy as np
import pylab as plt
data=np.loadtxt("sunspots.txt")
time=data[:,0]
y=data[:,1]
plt.plot(time,y)
plt.xlabel("time")
plt.ylabel("no of sunspot")
plt.title("sunspot vs time")
plt.show()


# In[ ]:




