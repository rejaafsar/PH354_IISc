#!/usr/bin/env python
# coding: utf-8

# In[5]:


from numpy.fft import rfft
from numpy import empty,array
from pylab import plot,xlabel,ylabel,title,show
N=1000
#datapoints
y=empty([N],float) 
for n in  range(N):
    y[n]=n
# FT coeffs
c=  rfft(y)

c=list(c)
for i in range(int(N/2-1),0,-1):
    c.append(complex(c[i].real,-c[i].imag))

plot(abs(array(c)))



# In[ ]:




