#!/usr/bin/env python
# coding: utf-8

# In[1]:


#hw8_a

from numpy import loadtxt
from pylab import imshow

#%% plotting of blurred figure
data=loadtxt("blur.txt",float)
imshow(data)


# In[ ]:




