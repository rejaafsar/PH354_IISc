#!/usr/bin/env python
# coding: utf-8

# In[3]:


#hw1_a
from numpy.fft import rfft
from numpy import ones
from pylab import plot,xlabel,ylabel,title,show
N=1000
y=ones([N],float) # datapoints
c=rfft(y)   # FTs

plot(abs(c))
show()



# In[ ]:




