#!/usr/bin/env python
# coding: utf-8

# In[ ]:


from numpy import loadtxt
from pylab import plot, xlabel, ylabel, title,show,legend,xlim

piano=loadtxt("piano.txt")
trumpet=loadtxt("trumpet.txt")
plot(piano,color="red")
title("piano")
show()
plot(trumpet,color='blue')
title("trumpet")
show()

