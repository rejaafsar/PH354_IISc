#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#hw5_a
from numpy import loadtxt
from numpy.fft import rfft,irfft
from pylab import plot, show,title, xlabel,ylabel,legend
y=loadtxt("dow2.txt")
plot(y,label='data')
legend()
xlabel("time")
ylabel('stock price')
title("stock price vs time")
show()


c=rfft(y)
N=len(c)
for i in range(int(0.02*N),N,1):
    c[i]=0
y_ift=irfft(c)
plot(y,color='green',label='data')
plot(y_ift,color='blue',label='ift')
legend()
xlabel("time")
ylabel('stock price')
show()

