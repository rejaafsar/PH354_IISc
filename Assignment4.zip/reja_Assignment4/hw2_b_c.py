#!/usr/bin/env python
# coding: utf-8

# In[1]:


#prob2_b_c

import numpy as np
from pylab import plot, show, xlabel, ylabel,title
data=np.loadtxt("sunspots.txt")
time=data[:,0]
y=data[:,1]
N=len(time)
# FT coeffs
c=  np.fft.rfft(y)
c=list(c)


#%% plotting amplitudes
plot(abs(np.array(c)))
xlabel("k")
ylabel("amplitude")
title("amp vs k")
show()
#%% finding  k for max magnitude
c_abs=list(abs(np.array(c)))
m=max(c_abs[2:1500])
k=c_abs.index(m)
T=N/k
print("k for max amplitude is = ",k)
print("time period= ",T)


# In[ ]:




