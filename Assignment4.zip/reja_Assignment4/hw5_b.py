#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#hw5_b

from numpy import loadtxt
from scipy.fft import dct,idct
from pylab import plot, show,title, xlabel,ylabel,legend
y=loadtxt("dow2.txt")

#%% 1st 2% coeff. zero
c=dct(y)
N=len(c)
for i in range(int(0.02*N),N,1):
    c[i]=0
y_ict=idct(c)
plot(y,color='green',label='data')
plot(y_ict,color='blue',label='ift')
legend()
xlabel("time")
ylabel('stock price')
show()


