#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#prob3_b
from numpy import loadtxt
from pylab import plot, xlabel, ylabel, title,show,legend,xlim,savefig
from numpy.fft import rfft
piano=loadtxt("piano.txt")
trumpet=loadtxt("trumpet.txt")

#  fft coefficients

c_piano=rfft(piano_y[:10000])
c_trumpet=rfft(trumpet_y[:10000])

# plotting for piano and trumpet
plot(abs(c_piano))
xlabel("k")
ylabel("amp")
title("amp vs k for piano")
show()
plot(abs(c_trumpet))
xlabel("k")
ylabel("amp")
title("amp vs k for trumpet")
show()
savefig("hw3_trumpet.jpg")
# frequency of maximum amplitude
freq_piano=list(abs(c_piano)).index(max(list(abs(c_piano))))
freq_trumpet=list(abs(c_trumpet)).index(max(list(abs(c_trumpet))))
print('max frequencies for piano and trumpet are  ',freq_piano,freq_trumpet,"Hz")

