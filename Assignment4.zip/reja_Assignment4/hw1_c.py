#!/usr/bin/env python
# coding: utf-8

# In[6]:


from numpy.fft import rfft
from numpy import empty,array
from pylab import plot,xlabel,ylabel,title,show
from math import sin,pi
N=1000
# datapoints
y=empty([N],float) 
for n in  range(N):
    y[n]=sin(pi*n/N)*sin(20*pi*n/N)
# FT coeffs
c=  rfft(y)

c=list(c)
for i in range(int(N/2-1),0,-1):
    c.append(complex(c[i].real,-c[i].imag))

plot(abs(array(c)))
show()



# In[ ]:




