#!/usr/bin/env python
# coding: utf-8

# In[18]:


#hw_8b

import numpy as np
import matplotlib.pyplot as plt
import random
from math import sqrt, cos

def f(x):
     return cos(x) + cos(sqrt(2)*x)+  cos(sqrt(3)*x)

Ti=1
Tf=0.001
alpha=1e4
k=0
x=0
x_pts=[0]
T=Ti
while T>Tf:
        E1=f(x)
        delta=np.random.normal(0,1,1000)[0]
        x=x+delta
        E2=f(x)
        dE=E2-E1
        if random.random()<np.exp(-dE/T):
            x=x
        else:
            x=x-delta
        if x>=0 and x<51:
            x_pts.append(x)
        k=k+1
        T=Ti*np.exp(-k/alpha)

plt.plot(x_pts,".")
plt.xlabel("time")
plt.ylabel("x")


# In[ ]:





# In[ ]:




