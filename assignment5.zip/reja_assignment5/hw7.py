#!/usr/bin/env python
# coding: utf-8

# In[ ]:


#hw_7
import numpy as np
import random
import matplotlib.pyplot as plt
from math import exp

##E=-S_i*S_j
def E(arr):
    y=0
    x=0
    z=0
    J=1
    r,c=arr.shape
    for i in range(r-1):
        x=x+arr[i,c-1]*arr[i+1,c-1]
        for j in range (c-1):
                y=y+arr[i,j]*arr[i,j+1]+arr[i,j]*arr[i+1,j]
          
    for j in range(c-1):
        z=z+arr[r-1,j]*arr[r-1,j+1]
    return -J*(x+y+z)

#A=np.array([[1,1,-1],[1,1,1],[1,1,1]])
#print(E(A))

####### spin asignment
#dim D
D=20
#Grid
B=np.empty([D,D],int)

for i in range(D):
    for j in range(D):
        if random.random()> 0.5:
            B[i,j] = 1
        else:
            B[i,j] = -1


##magnetization M
def M(arr):
    return np.sum(arr)

#print(B)
#print(E(B),M(B))

#Metropolis algo
T=1
N=10**6 #MC steps
M_list=[]
for n in range(N):
    # choosing the coordinate of the spin to be altered
    i =random.randrange(0,D)
    j =random.randrange(0,D)
    E1 = E(B)
    B[i, j] = -1*B[i, j] # spin flip
    E2 = E(B) 
    dE = E2 - E1 # energy difference
    p = random.random()
    if p < exp(-dE/T): # metropolis acceptance
        B[i,j]=B[i,j] 
        moment=M(B)
    else:                    
        B[i, j] = -1 * B[i, j] # rejected, restore original spin
        moment=M(B)
    M_list.append(moment)
    
plt.plot(M_list)
plt.show()
  

