#!/usr/bin/env python
# coding: utf-8

# In[2]:


#hw1_b
import random
c=0
for k in range(0,10**6):
    i=random.randint(1,7)
    j=random.randint(1,7) 
    if i==6 and j==6:
        #print(i,j)
        c=c+1
       
print(" number of  double six=",c,"probability=",c/k,"\t 1/36=",1/36)


# In[ ]:




