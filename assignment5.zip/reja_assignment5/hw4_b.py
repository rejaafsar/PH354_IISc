#!/usr/bin/env python
# coding: utf-8

# In[5]:


#hw4_b
from math import sin,sqrt
import random


def f(x):
    return (sin(1.0/(x*(2-x))))**2

N=10000
y=0.0
b=2.0
a=0.0
f_avg=0
f2_avg=0

for i in range(N):
    x=2*random.random()
    f_avg=f_avg+f(x)
    f2_avg=f2_avg+f(x)*f(x)
    
    
f_avg=f_avg/N
f2_avg=f2_avg/N

I=(b-a)*f_avg

varf=f2_avg - f_avg**2
#print(varf)
err=(b-a)*sqrt(varf/N)

print('integration I = ',I)
print(' error = ',err*100,'%') 


# In[ ]:




