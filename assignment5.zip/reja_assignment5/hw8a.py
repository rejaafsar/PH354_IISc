#!/usr/bin/env python
# coding: utf-8

# In[1]:


#hw_8a

import numpy as np
from math import exp
import matplotlib.pyplot as plt
import random

def f(x):
    return x**2-np.cos(4*np.pi*x)


Ti=1
Tf=0.001
alpha=1e4
k=0
x=2
x_pts=[2]
T=Ti
while T>Tf:
        E1=f(x)
        delta=np.random.normal(0,1,1000)[0]
        x=x+delta
        E2=f(x)
        dE=E2-E1
        if random.random()<exp(-dE/T):
            x=x
        else:
            x=x-delta
        k=k+1
        x_pts.append(x)
        T=Ti*exp(-k/alpha)

plt.plot(x_pts,".")
plt.xlabel("time")
plt.ylabel("x")


# In[ ]:




