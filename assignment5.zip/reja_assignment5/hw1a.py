#!/usr/bin/env python
# coding: utf-8

# In[1]:


#hw1_a
import random
i=random.randint(1,7)
j=random.randint(1,7) 
print("two random numbers between 1 and 6 are \t",i,"and",j)


# In[ ]:




