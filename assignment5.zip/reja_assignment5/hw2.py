#!/usr/bin/env python
# coding: utf-8

# In[21]:


import numpy as np
import matplotlib.pyplot as plt

N = 10000
N_Bi = N
N_Tl = 0
N_Pb = 0
N_final = 0


Tau_Pb = 3.3*60
Tau_Tl = 2.2*60
Tau_Bi = 46.0*60

N_Bi213 = []
N_Tl209 = []
N_Pb209 = []
N_Bi209 = []
T = []

 

N_Bi213.append(N_Bi)
N_Tl209.append(N_Tl)
N_Pb209.append(N_Pb)
N_Bi209.append(N_final)        
T.append(0)


p_Bi = 1-2**(-1/Tau_Bi)
p_Tl = 1-2**(-1/Tau_Tl)
p_Pb = 1-2**(-1/Tau_Pb)


 

for t in range(1, 20001):
    for i in range(0,N_Bi):
        if np.random.uniform()<=p_Bi:
            N_Bi = N_Bi-1
            if np.random.uniform()<0.9791:
                N_Pb = N_Pb+1
            else:
                N_Tl = N_Tl+1
    for i in range(0,N_Tl):
        if np.random.uniform()<=p_Tl:
            N_Tl = N_Tl-1
            N_Pb = N_Pb+1
    for i in range(0,N_Pb):
        if np.random.uniform()<=p_Pb:
            N_Pb = N_Pb-1
            N_final = N_final+1

 

    T.append(t)
    N_Bi213.append(N_Bi)
    N_Tl209.append(N_Tl)
    N_Pb209.append(N_Pb)
    N_Bi209.append(N_final)


plt.plot(T,N_Bi213, label = 'Bi_213')
plt.plot(T,N_Tl209, label = 'Tl_209')
plt.plot(T,N_Pb209, label = 'Pb_209')
plt.plot(T,N_Bi209, label = 'Bi_209')


plt.xlabel("time")
plt.ylabel("N")
plt.legend()
plt.show()


# In[ ]:




