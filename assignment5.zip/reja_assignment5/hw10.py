#!/usr/bin/env python
# coding: utf-8

# In[11]:


#hw_10
import random
from math import acos,pi

x1=random.random()
x2=random.random()
z1=acos(1-2*x1)
z2=x2*(2*pi)

print(z1,z2)


# In[ ]:




