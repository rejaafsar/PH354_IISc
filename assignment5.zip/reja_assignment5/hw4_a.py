#!/usr/bin/env python
# coding: utf-8

# In[4]:


#hw_4
import random
from math import sin, sqrt
c=0
N=10000
A=2  #from the max value of the function #a rectangle of 2*1  
for i in range(N):
    x=2*random.random()
    y=random.random()
    if y<=sin(1/(x*(2-x)))**2:
        c=c+1
I=c*A/N
err=sqrt(I*(A-I)/N)
print('integration I = ',I)
print(' error = ',err*100,'%')    


# In[ ]:




