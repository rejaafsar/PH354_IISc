#!/usr/bin/env python
# coding: utf-8

# In[8]:


#hw5
import random

N=10**6
c=0

#extending the given formule in the 10 dim would be =(2^10/N)* sum of points inside the hypersphere
# x1^2 +x2^2+...+x10^2 <=1 then f(xi)==1


for j in range(N):
    y=0
    for i in range(10):
        x=random.random()-random.random()
       # x=2*random.random()-1
        y=y+x**2
    if y<=1:
        c=c+1
       # print(j,y)
#print(c)

I=(2**10)*(c/N) 
print('Volume of 10 dimensional sphere  = ',I)


# In[ ]:




