#!/usr/bin/env python
# coding: utf-8

# In[7]:


#hw_7_e
import numpy as np
import random
import matplotlib.pyplot as plt

##E=-S_i*S_j
def E(arr):
    y=0
    x=0
    z=0
    J=1
    r,c=arr.shape
    for i in range(r-1):
        x=x+arr[i,c-1]*arr[i+1,c-1]
        for j in range (c-1):
                y=y+arr[i,j]*arr[i,j+1]+arr[i,j]*arr[i+1,j]
          
    for j in range(c-1):
        z=z+arr[r-1,j]*arr[r-1,j+1]
    return -J*(x+y+z)

#A=np.array([[1,1,-1],[1,1,1],[1,1,1]])
#print(E(A))

####### spin asignment
#dim D
D=20
#Grid
B=np.empty([D,D],int)

for i in range(D):
    for j in range(D):
        if random.random()> 0.5:
            B[i,j] = 1
        else:
            B[i,j] = -1


#print(B)
#print(E(B))

#Metropolis algo

N=10**4 #MC steps
M_list=[]
T=2   ### insert the value of T
print("for T=",T)

for n in range(N):
    # choosing the coordinate of the spin to be altered
        i =random.randrange(0,D)
        j =random.randrange(0,D)
        E1 = E(B)
        B[i, j] = -1*B[i, j] # spin flip
        E2 = E(B) 
        dE = E2 - E1 # energy difference
        p = random.random()
        if p < exp(-dE/T): # metropolis acceptance
            B[i,j]=B[i,j] 
        else:                    
            B[i, j] = -1 * B[i, j] # rejected, restore original spin
            
plt.imshow(B,origin='lower')
plt.show()    


# In[ ]:





# In[ ]:




