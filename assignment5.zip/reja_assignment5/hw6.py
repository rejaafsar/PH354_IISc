#!/usr/bin/env python
# coding: utf-8

# In[9]:


#hw_6
import random
from math import exp

N=10**6
y=0

def f(x):
    return 1/(exp(x)+1)


for j in range(N):
    x=random.random()
    z=x**2
    y=y+f(z)
    
I=2*(y/N)
print('integration I = ',I)


# In[ ]:




