#!/usr/bin/env python
# coding: utf-8

# In[3]:


#hw3
import numpy as np
import random
import matplotlib.pyplot as plt

x=0
y=0
x_pts=[]
y_pts=[]
for m in range(0,10**5):
    i=random.randrange(1,5)
    
    if i==1 and x>-50:
        x=x + (-1)
    elif i==2 and x<50:
         x=x +1
    elif i==3 and y>-50:
        y=y + (-1)
    elif  i==4 and y<50 :
        y=y +1    
    x_pts.append(x)
    y_pts.append(y)
   # print(x_pts[m],y_pts[m])
plt.plot(x_pts,y_pts)
plt.show()


# In[ ]:




