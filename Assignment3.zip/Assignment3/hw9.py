from math import exp


def  newton2(a, b, eps , func1 , func1p , func2 , func2p ):
   maxiter = 100
   xi = a
   yi = b
   i=0
   while (abs(func1(xi, yi)) > eps and  func2(xi, yi) > eps and i < maxiter ):
     i = i + 1
     f1 = func1(xi , yi)
     f2 = func2(xi , yi)
     f1x , f1y = func1p(xi , yi)
     f2x , f2y = func2p(xi , yi)
     den = f1x*f2y - f1y*f2x
     xip = xi + (f1y*f2 - f2y*f1)/den
     yip = yi + (f2x*f1 - f1x*f2)/den
     xi = xip
     yi = yip
   return xi, yi


Vplus,VT=5,0.05
R1,R2,R3,R4=1.,4.,3.,2.
Inot=3.E-6
def f(x,y):
    return (Vplus-x)/R1+(Vplus-y)/R3-x/R2-y/R4

def fp(x,y):
    return -(1./R1+1./R2),-(1./R3+1./R4)

def g(x,y):
    return (Vplus-x)/R1-Inot*exp((x-y)/VT)-x/R2

def gp(x,y):
    return -(1./R1+1./R2)-Inot/VT*exp((x-y)/VT),Inot/VT*exp((x-y)/VT)


V1,V2= newton2(0.5,5,1.E-6,f,fp,g,gp)
print ("the voltages are V1 (in volt)=",V1,"and V2(in volt)=",V2)
print ("voltage difference=" ,"%.3f" % (V1-V2) )

