import numpy as np
from numpy import array,empty

A = array([[ 4,-1,-1,-1 ],
           [-1,3,0,-1 ],
           [ -1,0,3,-1 ],
           [ -1,-1,-1,4 ]],float)
v = array([ 5,0,5,0 ],float)


N = len(v)



for k in range(N):   
   for j in range(k,N):
     if abs(A[j][k]) > abs(A[k][k]):  
        A[[k,j]] = A[[j,k]]
        v[k],v[j]=v[j],v[k]
       # print(k,j,"\n",A,"\n",v)
     else: 
        pass  
   

   div = A[k,k]
   A[k,:] /= div
   v[k] /= div

    # Now subtract from the lower rows
   for i in range(k+1,N):
        mult = A[i,k]
        A[i,:] -= mult*A[k,:]
        v[i] -= mult*v[k]
        #print(A,"\t",v)

# Backsubstitution
x = empty(N,float)
for m in range(N-1,-1,-1):
    x[m] = v[m]
    for i in range(m+1,N):
        x[m] -= A[m,i]*x[i]
#y=np.linalg.solve(A,v)
print(x)

