from math import exp
import numpy as np
from matplotlib import pylab as plb
def f(c,x):
   return 1-exp(-c*x)

#initial guess
x0=1;
tolerence= 1.E-6
while (abs(f(2,x0)-x0)>tolerence):
    x0=f(2,x0)
    print(x0)
print("\nsolution for c=2 is =",x0)


###part b
c_values=np.arange(0,3.01,.01)
roots=[]
for c in c_values:
    x0=1
    while (abs(f(c,x0)-x0)>tolerence):
       x0=f(c,x0)
    roots.append(x0)

plb.plot(c_values,roots)
plb.xlabel("c")
plb.ylabel("roots")
plb.title("percolation transition")
plb.show()

