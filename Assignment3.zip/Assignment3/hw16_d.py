from  numpy import zeros,pi
from math import pi
from numpy.linalg import eigvalsh


a=10 #eV
M=9.1094e-31 #kg
q=1.62022e-19 # c
h=6.62e-34 #si unit
L=5e-10


K=(h**2/((8*M*L**2)))*6.242e18 #in eV

print("constant K value is=",K,"eV")
rows,cols=100,100
H=zeros([rows,cols],float)

for i in range(rows):
    m=i+1
    for j in range(cols):
        n=j+1
        if m==n:
            H[i,j]=m*m*K+a/2
        elif (m%2==0 and n%2==1)or(m%2==1 and n%2==0):
            H[i,j]=-(8*a*m*n)/(pi*pi*(m*m-n*n)**2)
        
print(H)
x=eigvalsh(H)
a=(x[:10])
b=[ 5.8524058,   11.22681902,  18.76626115, 29.32901849,  42.94439179,
  59.60216525,  79.29699193, 102.0269879,  127.78992408, 156.7130988 ]
error=(a-b)*100/a
print("the 1st ten eigenvalues are")
for i in range(10):
    print( a[i],"eV &  error=",(a[i]-b[i])*100/a[i],"%")
