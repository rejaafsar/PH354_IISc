
def f(x):
    return x*(x-1)

def derivative(x,delta):
    return (f(x+delta)-f(x))/delta

print ("Derivative at x=1 for delta= 1.E-2",derivative(1.0,1.E-2))
delta_list=[1.E-4,1.E-6,1.E-8,1.E-10,1.E-12,1.E-14]
for delta in delta_list:
    print ("Derivative at x=1 for delta=",delta,"is" ,derivative(1.,delta))
