from math import  sqrt

def f1(a,b,c):
    root1=(-b+sqrt(b**2-4*a*c))/(2.0*a)
    root2=(-b-sqrt(b**2-4*a*c))/(2.0*a)
    return root1,root2
print ("\n 1st case : root1,root2=",f1(0.001,1000,0.001))

def f2(a,b,c):
    root1=(2.0*c)/(-b-sqrt(b**2-4*a*c))
    root2=(2.0*c)/(-b+sqrt(b**2-4*a*c))
    return root1,root2
print ("\n 2nd case : root1,root2=",f2(0.001,1000,0.001))

def Newton_Raphson(a,b,c,tolerance):
    x0=-b/(a)
    x1 =x0- ((a * x0 ** 2 + b * x0 + c) / (2 * a * x0 + b))
    while (x0-x1) > tolerance:
        x0=x1
        x1=x0- ((a * x0 ** 2 + b * x0 + c) / (2 * a * x0 + b))
    root1=x1

    x0=0.
    x1 =x0- ((a * x0 ** 2 + b * x0 + c) / (2 * a * x0 + b))
    while (x0-x1) > tolerance:
        x0=x1
        x1=x0- ((a * x0 ** 2 + b * x0 + c) / (2 * a * x0 + b))
    root2=x1
    return root1,root2
print ("\nroot1,root2=",Newton_Raphson(.001,1000,.001,1.E-6))
