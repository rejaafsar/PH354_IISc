
G=6.674*10**-11
M=5.974*10**24
m=7.348*10**22
R=3.844*10**8
w=2.662*10**-6
k1=M/m
k2=w*w/(G*M)

def fx(x):
    return k1/x**2-1./(R-x)**2-k2*x



def  secant(a, b, eps , func):
   maxiter = 1000
   xi = a
   xim = b
   i = 0
   while (abs(func(xi)) > eps  and abs(func(xi)-func(xim)) > eps and i < maxiter ):
     i = i + 1
     xip = (xim*func(xi) - xi*func(xim))/(func(xi)-func(xim))
     xim = xi
     xi = xip
   return  xi

xroot= secant(3.45e8,3.85e8,1.E-6,fx)
print ("the lagrangian point is at a distance ")
print ("%.4E"% xroot,"m")

