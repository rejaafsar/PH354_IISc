from  math import exp

def g(x,c):
    return 1.-exp(-c*x)

def f(c, eps):
    x0 = 1.0    # intial guess
    r0=1./(2.*exp(-2)-1)
    x1 =x0+r0*(x0-g(x0, c))
    i=1.0
    while abs(x1-x0)>eps:
        x0=x1
        x1 =x0+r0*(x0-g(x0, c))
        i+=1 
        
    return x1,i
print ("solution ,iteration no =",f(2, 1.E-6))
