from math import exp
const=0.01915 #const=hc/k
def f(x):
    return  exp(x)*(1-x/5)-1
def bisection(func,a,b,accuracy):
    c=(a+b)/2.
    i=1
    maxiter=1000
    while abs(func(c))>accuracy:
        if func(a)*func(c)<0:
            b=c
        else:
            a=c
        c=(a+b)/2.
        i +=1
        if i>maxiter:
            print ("doesnt converge even after maxiter steps")
            break
    return c
x0= bisection(f,1.,10.,1.E-6)
Lambda=502*10**-9
T=(const/x0)*(1./Lambda)
print ("temp of sun is ", T,"K")
