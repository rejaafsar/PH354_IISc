import numpy as np
from  numpy import zeros,pi
from math import pi
from numpy.linalg import eig
import matplotlib.pyplot as plt

a=10 #eV
M=9.1094e-31 #kg
q=1.62022e-19 # c
h=6.62e-34 #si unit
L=5e-10


K=(h**2/((8*M*L**2)))*6.242e18 #in eV

print("constant K value is=",K,"eV")
rows,cols=100,100
H=zeros([rows,cols],float)

for i in range(rows):
    m=i+1
    for j in range(cols):
        n=j+1
        if m==n:
            H[i,j]=m*m*K+a/2
        elif (m%2==0 and n%2==1)or(m%2==1 and n%2==0):
            H[i,j]=-(8*a*m*n)/(pi*pi*(m*m-n*n)**2)

E,V=eig(H)
c1,c2,c3=V[:,0],V[:,1],V[:,2]

def psi0(x):
    psi=0
    for i in range(rows):
        psi +=c1[i]*np.sin(i*np.pi*x/L)
    return psi
def psi1(x):
    psi=0
    for i in range(rows):
        psi +=c2[i]*np.sin(i*np.pi*x/L)
    return psi
def psi2(x):
    psi=0
    for i in range(rows):
        psi +=c3[i]*np.sin(i*np.pi*x/L)
    return psi
X=np.linspace(0,5,100)
psi_0=psi0(X)*psi0(X)
psi_1=psi1(X)*psi1(X)
psi_2=psi2(X)*psi2(X)

plt.plot(X,psi_0,label="psi0",color="red")
plt.plot(X,psi_1,label="psi1",color="blue")
plt.plot(X,psi_2,label="psi2",color="orange")
plt.show()
