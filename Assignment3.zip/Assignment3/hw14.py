import numpy as np
N=6
v_plus=5
A=np.zeros([N,N],float)
for i in  range(N):
    if i==0:
        A[i,i],A[i,i+1],A[i,i+2]=3,-1,-1
    elif i==N-1:
        A[i, i], A[i, i - 1], A[i, i - 2] = 3, -1, -1
    else:
        A[i,i]=4
        for j in range(i-2,i+3,1):
            if j>=0 and j!=i and j<N:
                A[i, j] = -1
v=np.zeros([N],float)
v[0],v[1]=v_plus,v_plus
x = np.linalg.solve(A, v)     
print(A)
print(v)
print(x)
