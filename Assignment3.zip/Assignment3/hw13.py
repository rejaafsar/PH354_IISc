import numpy as np
import cmath
R1,R3,R5=1e3,1e3,1e3
R2,R4,R6=2e3,2e3,2e3
C1,C2=1e-6,0.5e-6
x_plus,w=3,1000

A=np.array([[1/R1+1/R4+1j*w*C1,  -1j*w*C1,  0],
            [-1j*w*C1, 1/R2+1/R5+1j*w*C1+1j*w*C2, -1j*w*C2 ],
            [0, -1j*w*C2, 1/R3+1/R6+1j*w*C2]])
v = np.array([  x_plus/R1,   x_plus/R2,  x_plus/R3])
x = np.linalg.solve(A, v)
for i in range(len(v)):
    r,theta=cmath.polar(x[i])
    print("amplitude V",i+1,"=",r,"volt")
    print("phase of  V",i+1,"=",theta*180,"degree")

