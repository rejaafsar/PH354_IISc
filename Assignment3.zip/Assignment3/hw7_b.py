from math import pow

def P(x):
    return 924*pow(x,6)-2772*pow(x,5)+3150*pow(x,4)-1680*pow(x,3)+420*pow(x,2)-42*pow(x,1)+1
def P_prime(x):
    return 924*6*pow(x,5)-2772*5*pow(x,4)+3150*4*pow(x,3)-1680*3*pow(x,2)+420*2*x-42
def Newton(x0,accuracy):
    x1=x0-P(x0)/P_prime(x0)
    iternum =1
    maxiter=1000
    while abs(P(x1))>accuracy:
        x0=x1
        x1 = x0 - P(x0) / P_prime(x0)
        iternum +=1
        if iternum >maxiter:
            print ("doesnt converge even after maxiter iterations ")
            break
    return x1
print ("the roots are ")
tol=1.E-10
print ("roota are at x= ",Newton(0.025,tol),Newton(0.16,tol),Newton(0.35,tol),Newton(0.55,tol),Newton(0.8,tol),Newton(0.98,tol))
