import  numpy as np
from math import pow
from matplotlib import pylab as plb
xpts=np.arange(0,1.,0.001)
def P(x):
    return 924*pow(x,6)-2772*pow(x,5)+3150*pow(x,4)-1680*pow(x,3)+420*pow(x,2)-42*pow(x,1)+1
ypts=[]
for x in xpts:
    ypts.append(P(x))
plb.plot(xpts,ypts)
plb.axhline(0.0,color="red") 
plb.ylabel("P6")
plb.show()
